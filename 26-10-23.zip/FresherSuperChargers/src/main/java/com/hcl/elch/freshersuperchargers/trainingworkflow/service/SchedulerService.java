package com.hcl.elch.freshersuperchargers.trainingworkflow.service;

public interface SchedulerService {
	public void fetchTask() throws Exception;
}
