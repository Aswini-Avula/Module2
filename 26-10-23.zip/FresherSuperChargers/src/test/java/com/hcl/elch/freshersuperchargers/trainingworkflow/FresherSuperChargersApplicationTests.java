package com.hcl.elch.freshersuperchargers.trainingworkflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@SpringBootTest
//@ContextConfiguration
class FresherSuperChargersApplicationTests {

	@Test
	void contextLoads() {
	}

}
